export default function Login() {
  const clientId = process.env.NEXT_PUBLIC_DISCORD_CLIENT_ID;
  const redirect = encodeURIComponent(process.env.NEXT_PUBLIC_DISCORD_REDIRECT_URI || "");
  const url = `https://discord.com/oauth2/authorize?client_id=${clientId}&redirect_uri=${redirect}&response_type=code&scope=identify%20guilds&prompt=consent`;
  return (
    <main style={{minHeight:"100vh",display:"grid",placeItems:"center",background:"#050505"}}>
      <a href={url} style={{padding:"16px 32px",background:"#5865F2",color:"#fff",borderRadius:12,textDecoration:"none",fontWeight:700}}>تسجيل الدخول بـ Discord</a>
    </main>
  );
}