export default function Home() {
  return (
    <main style={{minHeight:"100vh",display:"grid",placeItems:"center",background:"radial-gradient(circle at 50% 20%,#111,#000)"}}>
      <div style={{textAlign:"center",padding:40,border:"1px solid #222",borderRadius:24,background:"#0a0a0a",maxWidth:520}}>
        <h1 style={{fontSize:48,margin:0}}>7lb</h1>
        <p style={{color:"#aaa",marginTop:8}}>لوحة إدارة بوت ديسكورد متكاملة</p>
        <a href="/login" style={{display:"inline-block",marginTop:24,padding:"14px 28px",background:"#fff",color:"#000",borderRadius:12,textDecoration:"none",fontWeight:700}}>تسجيل الدخول عبر Discord</a>
      </div>
    </main>
  );
}