export const metadata = { title: "7lb Dashboard" };
export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl">
      <body style={{margin:0,background:"#050505",color:"#fff",fontFamily:"system-ui,sans-serif"}}>{children}</body>
    </html>
  );
}