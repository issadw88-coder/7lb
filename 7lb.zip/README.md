# 7lb Dashboard
ارفع محتويات هذا المجلد إلى GitHub ثم استورده في Vercel.